Discrete Orthogonal Toolbox for 2D Data: dop2DBox Version V2.0

July 2013

Introduction
------------

This toolbox extends the discrete orthogonal toolbox "dopBox" available 

 http://www.mathworks.com/matlabcentral/fileexchange/41250

to modelling of 2D data sets. Presently the modelling is for datawhich lies on a grid (regular lattice). For example, the tools are particularly well suited for use with images and for regularly scanned surface data.


The toolbox implements a number of 2D algorithms:

The following transformation pair, represent the first Gram and inverse Gram transformations which can deal with images of size > 1000 x 1000 pixels without errors.

dgt2: 			A 2D Gram polynomial transformation.
idgt2: 			Inverse 2D Gram polynomial transformation.

dop2DApprox: 		a 2D Gram polynomial approximation.
dop2DApproxLocal: 	a local 2D Gram polynomial approximation.

dop2DGradient: 		A 2D gradient computation with and without spectral regularization.

Demos
-----

The toolbox contains four demonstration applications, with corresponding theory:

1) A 2D surface approximation, with the seperation of local surface anomalies from a global surface model.
2) Image illumination correction
3) Regularized and non-regularized gradient computation form surface data.
4) A 2D Gram Transformation and its inverse 

Theory
------
The theory behind the surface modelling for real time surface sinpection can be found in the paper:

@article{doi:10.1117/1.2987725,
author = {O'Leary, Paul and Harker, Matthew},
title = {Discrete polynomial moments for real-time geometric surface inspection},
journal = {Journal of Electronic Imaging},
volume = {18},
number = {1},
pages = {013015-013015-13},
year = {2009},
doi = {10.1117/1.2987725},
URL = { + http://dx.doi.org/10.1117/1.2987725},
eprint = {}
}

http://dx.doi.org/10.1117/1.2987725

The theory was also extended to circular disks and can be found in:

@inproceedings{
Janko2013,
   Author = {Janko, M. and O'Leary, P. and Harker, M.},
   Title = {Instrumentation for the 3D Measurement of Circular
   Disks and the Quantification of Warpage},
   BookTitle = {IEEE International Instrumentation and Measurement Technology Conference},
   Address= {Minneapolis, Minnesota, USA },
   Publisher = {IEEE},
   Pages = {146..150},
   Year = {2013} }
